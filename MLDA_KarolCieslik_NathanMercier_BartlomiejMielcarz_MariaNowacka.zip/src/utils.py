import numpy as np

def calculate_forward_alpha(stock_future_ret, spy_future_ret):
    """Calculates the excess rate of return (Alpha)"""
    if stock_future_ret is None or spy_future_ret is None:
        raise ValueError("Dane wejściowe nie mogą być None")
    return stock_future_ret - spy_future_ret

def check_data_leakage(train_dates, test_date):
    """It ensures that no training date is equal to or later than the test date"""
    for d in train_dates:
        if d >= test_date:
            return True # Data leakage detected!
    return False
