import pytest
import pandas as pd
from utils import calculate_forward_alpha, check_data_leakage

def test_calculate_forward_alpha_correctness():
    # Test wherther subtracting the returns work properly
    stock_ret = 0.05  # +5%
    spy_ret = 0.02    # +2%
    expected_alpha = 0.03
    
    assert calculate_forward_alpha(stock_ret, spy_ret) == pytest.approx(expected_alpha)

def test_calculate_forward_alpha_raises_value_error():
    # Test whether function yields the error correctly
    with pytest.raises(ValueError):
        calculate_forward_alpha(None, 0.02)

def test_check_data_leakage_safe():
    # Test data leakage - no leakage
    train_dates = [pd.Timestamp('2014-01-01'), pd.Timestamp('2014-12-31')]
    test_date = pd.Timestamp('2015-01-01')
    
    assert check_data_leakage(train_dates, test_date) == False

def test_check_data_leakage_detected():
    # Test data leakage - no leakage
    train_dates = [pd.Timestamp('2014-01-01'), pd.Timestamp('2015-01-02')]
    test_date = pd.Timestamp('2015-01-01')
    
    assert check_data_leakage(train_dates, test_date) == True
